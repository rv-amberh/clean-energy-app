import ChartHolder from '../components/ChartHolder'

const CarbonData = () => {
  return (
    <>
    <ChartHolder />
    </>
  )
}

export default CarbonData


